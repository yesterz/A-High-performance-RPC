package com.yesterz.netty.constant;

public class Constants {

    public static final String SERVER_PATH = "/netty/";
}