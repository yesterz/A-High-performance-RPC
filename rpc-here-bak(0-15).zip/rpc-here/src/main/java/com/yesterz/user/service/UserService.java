package com.yesterz.user.service;

import com.yesterz.user.bean.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    public void save(User user) {
        // 访问MySQL
        // 数据库层面的操作
    }

    public void saveList(List<User> users) {

    }
}
